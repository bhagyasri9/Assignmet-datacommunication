import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component implements OnInit {

  @Output() gevent=new EventEmitter();
 
  user={
    "name":"Riya","address":"Hyderabad"
  };
  
  constructor() { }

  ngOnInit() {

  }
  display(){
    this.gevent.emit(this.user);
    
  }
  
  
}
