import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  companyData=[
    {"id":1101,"name":"HCL","address":"Noida"},
    {"id":1102,"name":"TCS","address":"Hyderabad"},
    {"id":1103,"name":"Wipro","address":"Banglore"},
  ];

  data(name: string){
    alert(`Data was ${name}`);
  }
  title = 'send data between components' ;

  
}
